# EXE Host — Windows 11

A private web dashboard for uploading EXE files and starting/stopping them on the Windows 11 machine running this Node.js server. It supports administrator-created trusted accounts, per-user program ownership, process status, basic stdout/stderr logs, and deletion.

## Important security warning

**This app executes uploaded Windows programs on the host PC.** A trusted account can still upload a malicious or compromised executable. The process runs with the Windows account permissions of the Node.js server. This starter project does not provide a VM/container sandbox, malware scanning, CPU/RAM quotas, or protection against hostile executables.

- Keep it bound to `127.0.0.1` unless you have secured it.
- Do not port-forward it or expose it directly to the public internet.
- Only create accounts for people you personally trust, and only allow files you have independently checked.
- For remote access, use a VPN such as Tailscale or WireGuard and HTTPS; do not simply change the host to `0.0.0.0`.
- For genuinely untrusted uploads, run each executable in a separate disposable Windows VM with restricted networking and no access to host files. This project is not that isolation layer.
- The built-in Express memory session store is suitable only for local testing. Use a persistent session store and a reverse proxy with TLS before any multi-user network deployment.
- Use a dedicated, non-administrator Windows account for the Node server. Do not run it as Administrator.
- Windows GUI apps may not work as expected when started as background processes; this manager is intended primarily for console/background programs.
- Stop is a best-effort termination of the direct process. An EXE may launch child processes that need separate cleanup.

## Requirements

- Windows 11
- Node.js 20 or newer (LTS recommended)
- PowerShell or Windows Terminal

## Install and run

1. Extract the ZIP to a folder, for example `C:\\exe-host`.
2. Open PowerShell in that folder.
3. Install dependencies:

   ```powershell
   npm install
   ```

4. Create the first administrator:

   ```powershell
   npm run create-admin
   ```

   Choose a username and a password of at least 12 characters.

5. Start the website:

   ```powershell
   npm start
   ```

6. Open `http://127.0.0.1:3000` in your browser and sign in.

## Add trusted users

Sign in as the administrator. In the **Trusted users** section, create an account and give its username and temporary password to the person you trust. There is no public registration page. Users can upload and manage their own programs; administrators can see all programs and revoke accounts.

## Data locations

- `data/users.json` — password hashes and account roles
- `data/programs.json` — uploaded program metadata
- `data/uploads/` — stored EXE files

Back up the `data` folder while the service is stopped. Never publish it.

## Configuration

By default, the server listens only on `127.0.0.1:3000`. You can change the port with `PORT`, but keep the host local unless you have deployed proper network security.

Example PowerShell:

```powershell
$env:PORT = "3000"
npm start
```

A random session secret should be configured before any network deployment:

```powershell
$env:SESSION_SECRET = "replace-with-a-long-random-secret"
```

Do not use the sample fallback secret for network access.

## Current limitations

- Uploaded files are checked for the `.exe` extension and `MZ` header only. This is not a malware scan.
- Programs are not automatically restarted.
- Process tracking is in memory; after the Node server restarts, the dashboard no longer tracks earlier process handles.
- The logs view captures stdout/stderr only when the executable writes to those streams.
- There are no CPU/RAM metrics or per-process resource limits in this starter version.
