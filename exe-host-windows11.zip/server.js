const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");

const app = express();
const PORT = Number(process.env.PORT || 3000);
// Safe default: reachable only from this Windows PC.
const HOST = process.env.HOST || "127.0.0.1";
const DATA = path.join(__dirname, "data");
const UPLOADS = path.join(DATA, "uploads");
const USERS_FILE = path.join(DATA, "users.json");
const PROGRAMS_FILE = path.join(DATA, "programs.json");
const MAX_UPLOAD = 100 * 1024 * 1024;

fs.mkdirSync(UPLOADS, { recursive: true });
for (const f of [USERS_FILE, PROGRAMS_FILE]) {
  if (!fs.existsSync(f)) fs.writeFileSync(f, "[]");
}

const readJson = f => JSON.parse(fs.readFileSync(f, "utf8"));
const writeJson = (f, v) => fs.writeFileSync(f, JSON.stringify(v, null, 2));
const users = () => readJson(USERS_FILE);
const programs = () => readJson(PROGRAMS_FILE);
const live = new Map(); // Process handles are intentionally in-memory only.

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
    imgSrc: ["'self'", "data:"], connectSrc: ["'self'"], objectSrc: ["'none'"],
    baseUri: ["'self'"], frameAncestors: ["'none'"]
  }
}}));
app.use(express.json({ limit: "32kb" }));
app.use(session({
  name: "exehost.sid",
  secret: process.env.SESSION_SECRET || "CHANGE_THIS_SESSION_SECRET_BEFORE_NETWORK_USE_7f9d2a",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.COOKIE_SECURE === "true", maxAge: 8 * 60 * 60 * 1000 }
}));

// Reject cross-site state-changing requests. Same-origin dashboard requests pass.
app.use((req, res, next) => {
  if (["POST", "DELETE", "PUT", "PATCH"].includes(req.method)) {
    const origin = req.get("origin");
    if (origin) {
      const expected = `${req.protocol}://${req.get("host")}`;
      if (origin !== expected) return res.status(403).json({ error: "Cross-origin request blocked." });
    }
  }
  next();
});

function auth(req, res, next) {
  const user = users().find(u => u.id === req.session.userId);
  if (!user) return res.status(401).json({ error: "Please sign in." });
  req.user = user;
  next();
}
function admin(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  next();
}
function canAccess(req, p) {
  return req.user.role === "admin" || p.ownerId === req.user.id;
}
function publicProgram(p) {
  const child = live.get(p.id);
  return {
    id: p.id, name: p.name, owner: users().find(u => u.id === p.ownerId)?.username || "Unknown",
    createdAt: p.createdAt, status: child && child.proc.exitCode === null && !child.proc.killed ? "running" : "stopped",
    pid: child?.proc.pid || null, logs: child?.logs || []
  };
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, _file, cb) => cb(null, crypto.randomUUID() + ".exe")
});
const upload = multer({
  storage, limits: { fileSize: MAX_UPLOAD, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() !== ".exe") return cb(new Error("Only .exe files are accepted."));
    cb(null, true);
  }
});

app.get("/api/me", (req, res) => {
  const u = users().find(x => x.id === req.session.userId);
  res.json({ user: u ? { id: u.id, username: u.username, role: u.role } : null });
});

app.post("/api/login", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const user = users().find(u => u.username.toLowerCase() === username.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not create session." });
    req.session.userId = user.id;
    res.json({ user: { id: user.id, username: user.username, role: user.role } });
  });
});
app.post("/api/logout", auth, (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/programs", auth, (req, res) => {
  res.json({ programs: programs().filter(p => canAccess(req, p)).map(publicProgram) });
});

app.post("/api/upload", auth, (req, res) => {
  upload.single("exe")(req, res, err => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: "Choose an EXE file." });
    // Basic PE signature check only; this does NOT establish that a file is safe.
    const fd = fs.openSync(req.file.path, "r");
    const header = Buffer.alloc(2);
    fs.readSync(fd, header, 0, 2, 0);
    fs.closeSync(fd);
    if (header.toString("ascii") !== "MZ") {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: "This file does not have a Windows executable header." });
    }
    const list = programs();
    const p = {
      id: path.basename(req.file.filename, ".exe"),
      name: path.basename(req.file.originalname, ".exe").slice(0, 100),
      diskName: req.file.filename, ownerId: req.user.id, createdAt: new Date().toISOString()
    };
    list.push(p);
    writeJson(PROGRAMS_FILE, list);
    res.json({ program: publicProgram(p) });
  });
});

app.post("/api/programs/:id/start", auth, (req, res) => {
  const p = programs().find(x => x.id === req.params.id);
  if (!p || !canAccess(req, p)) return res.status(404).json({ error: "Program not found." });
  const existing = live.get(p.id);
  if (existing && existing.proc.exitCode === null && !existing.proc.killed) {
    return res.status(409).json({ error: "Program is already running." });
  }

  const exePath = path.join(UPLOADS, p.diskName);
  if (!fs.existsSync(exePath)) return res.status(404).json({ error: "Executable file is missing." });

  // Deliberately no shell, no user-supplied arguments, and no command-string interpolation.
  // WARNING: this still runs the uploaded binary with this Windows account's permissions.
  const proc = spawn(exePath, [], { cwd: UPLOADS, windowsHide: true, shell: false, detached: false });
  const entry = { proc, logs: [], startedAt: new Date().toISOString() };
  const addLog = (stream, chunk) => {
    const lines = chunk.toString("utf8").split(/\r?\n/).filter(Boolean);
    for (const line of lines) entry.logs.push({ time: new Date().toISOString(), stream, text: line.slice(0, 2000) });
    if (entry.logs.length > 300) entry.logs.splice(0, entry.logs.length - 300);
  };
  proc.stdout?.on("data", c => addLog("out", c));
  proc.stderr?.on("data", c => addLog("err", c));
  proc.on("error", e => addLog("system", Buffer.from(e.message)));
  proc.on("exit", (code, signal) => addLog("system", Buffer.from(`Process exited: code=${code}, signal=${signal}`)));
  live.set(p.id, entry);
  res.json({ ok: true, program: publicProgram(p) });
});

app.post("/api/programs/:id/stop", auth, (req, res) => {
  const p = programs().find(x => x.id === req.params.id);
  if (!p || !canAccess(req, p)) return res.status(404).json({ error: "Program not found." });
  const entry = live.get(p.id);
  if (!entry || entry.proc.exitCode !== null || entry.proc.killed) return res.status(409).json({ error: "Program is not running." });
  // Stops the launched process. Child processes created by the EXE may need separate handling.
  entry.proc.kill();
  res.json({ ok: true });
});

app.get("/api/programs/:id/logs", auth, (req, res) => {
  const p = programs().find(x => x.id === req.params.id);
  if (!p || !canAccess(req, p)) return res.status(404).json({ error: "Program not found." });
  res.json({ logs: live.get(p.id)?.logs || [] });
});

app.delete("/api/programs/:id", auth, (req, res) => {
  const list = programs();
  const p = list.find(x => x.id === req.params.id);
  if (!p || !canAccess(req, p)) return res.status(404).json({ error: "Program not found." });
  const entry = live.get(p.id);
  if (entry && entry.proc.exitCode === null && !entry.proc.killed) return res.status(409).json({ error: "Stop the program before deleting it." });
  try { fs.unlinkSync(path.join(UPLOADS, p.diskName)); } catch {}
  writeJson(PROGRAMS_FILE, list.filter(x => x.id !== p.id));
  live.delete(p.id);
  res.json({ ok: true });
});

// Only administrators can create trusted accounts. No public sign-up endpoint exists.
app.get("/api/users", auth, admin, (_req, res) => {
  res.json({ users: users().map(u => ({ id: u.id, username: u.username, role: u.role, createdAt: u.createdAt })) });
});
app.post("/api/users", auth, admin, async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_-]{3,32}$/.test(username)) return res.status(400).json({ error: "Username must be 3-32 characters using letters, numbers, _ or -." });
  if (password.length < 12) return res.status(400).json({ error: "Password must be at least 12 characters." });
  const list = users();
  if (list.some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: "Username already exists." });
  const user = { id: crypto.randomUUID(), username, passwordHash: await bcrypt.hash(password, 12), role: "user", createdAt: new Date().toISOString() };
  list.push(user); writeJson(USERS_FILE, list);
  res.json({ user: { id: user.id, username, role: user.role } });
});
app.delete("/api/users/:id", auth, admin, (req, res) => {
  if (req.params.id === req.user.id) return res.status(400).json({ error: "You cannot delete your own administrator account." });
  const list = users();
  const target = list.find(u => u.id === req.params.id);
  if (!target) return res.status(404).json({ error: "User not found." });
  const owned = programs().filter(p => p.ownerId === target.id);
  if (owned.some(p => { const e = live.get(p.id); return e && e.proc.exitCode === null && !e.proc.killed; })) {
    return res.status(409).json({ error: "Stop this user's running programs before deleting the account." });
  }
  for (const p of owned) { try { fs.unlinkSync(path.join(UPLOADS, p.diskName)); } catch {} live.delete(p.id); }
  writeJson(PROGRAMS_FILE, programs().filter(p => p.ownerId !== target.id));
  writeJson(USERS_FILE, list.filter(u => u.id !== target.id));
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public")));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

const server = app.listen(PORT, HOST, () => {
  console.log(`EXE Host listening at http://${HOST}:${PORT}`);
  console.log("Local-only by default. Read SECURITY.md before exposing this service to a network.");
});
function shutdown() {
  for (const entry of live.values()) {
    try { if (entry.proc.exitCode === null && !entry.proc.killed) entry.proc.kill(); } catch {}
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
