const fs = require("fs");
const path = require("path");
const readline = require("readline");
const bcrypt = require("bcryptjs");

const dataDir = path.join(__dirname, "data");
const usersFile = path.join(dataDir, "users.json");
fs.mkdirSync(dataDir, { recursive: true });

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(resolve => rl.question(q, resolve));

(async () => {
  const username = (await ask("Admin username: ")).trim();
  const password = await ask("Admin password (12+ characters): ");
  rl.close();

  if (!/^[a-zA-Z0-9_-]{3,32}$/.test(username)) {
    console.error("Username must be 3-32 characters: letters, numbers, _ or -.");
    process.exit(1);
  }
  if (password.length < 12) {
    console.error("Use a password of at least 12 characters.");
    process.exit(1);
  }

  const users = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile, "utf8")) : [];
  if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    console.error("That username already exists.");
    process.exit(1);
  }
  users.push({
    id: require("crypto").randomUUID(),
    username,
    passwordHash: await bcrypt.hash(password, 12),
    role: "admin",
    createdAt: new Date().toISOString()
  });
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
  console.log("Administrator created. Start the site with: npm start");
})().catch(err => { console.error(err); process.exit(1); });
