# Security deployment checklist

This application launches user-uploaded executable code. The safest initial deployment is local-only on `127.0.0.1`, using files you have personally verified.

Before allowing access from another device:
- Put the service behind an authenticated VPN; do not expose port 3000 to the internet.
- Use HTTPS with secure cookies and a persistent session store.
- Change the session secret to a cryptographically random value.
- Run Node under a dedicated standard Windows account with access only to the application data directory.
- Keep Windows and Node.js patched.
- Restrict outbound network access and filesystem access for launched programs.
- Prefer one disposable Windows VM per execution job/user, with snapshots and no shared credentials.
- Add resource limits, job-object process-tree management, antivirus scanning, audit logs, and quotas.
- Review and test the threat model before enabling uploads from anyone else.

This starter project does not implement VM isolation. A password-protected dashboard is not a sandbox.
